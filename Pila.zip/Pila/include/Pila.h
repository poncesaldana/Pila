/**
Nombre de los integrantes: Ponce Dominguez Isaac Luis
		           Saldaña Avila Armando
*/

#include "Nodo.h"

class Pila{

public:
	//Atributos
	Nodo *Tope;
	//Constructores
	Pila();
	Pila(int Dato);
	//Metodos
	void Push(int Dato);
	int Pop();
	bool isVacia();
	Buscar();
}

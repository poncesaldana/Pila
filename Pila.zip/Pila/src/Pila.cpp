/**
Nombre de los integrantes: Ponce Dominguez Isaac Luis
		           Saldaña Avila Armando
*/

#include "Pila.h"

/**
Creamos una pila vacia
*/

Pila::Pila(){
	this->Tope = NULL;
}

/**
Creamos una pila con un dato
*/

Pila::Pila(int Dato){
	Nodo *aux = new Nodo(Dato);
	this->Tope = aux;
}

/**
Se Agrega un dato hasta la cima de la pila
*/

void Pila::Push(int Dato){
	Nodo m(dato, this->H);
	if(isVacia()){
		T=M;
	}
	H=M;	
}

/**
Eliminanamos el tope, guardamos ese dato y recorremos el tope al siguiente elemento
*/

int Pila::Pop(){
	Nodo aux=this->H;
	this->H=this->H*Sig;
	if(this->H==Null)
		this->T=Null;
	aux*Sig=Null;
}

/**
Buscamos un elemento de la pila
*/

Nodo Pila::Buscar(int ref){
	Nodo aux=this->H;
	while(aux.dato!=ref){
		if(aux.sig==Null){
			//Mensaje de no encontrado
			return Null;
		}
		aux=aux*Sig;
	}	
	return aux;	
}

/**
Nos aseguramos que la pila este vacia
*/

void Pila::isVacia(){
	if (this->H == NULL && this->T == NULL)
		return true;
	return false;
}






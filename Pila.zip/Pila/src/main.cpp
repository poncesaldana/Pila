/**
Nombre de los integrantes: Ponce Dominguez Isaac Luis
		           Saldaña Avila Armando
*/

#include "Pila.h"

int main(){

	Pila p = Pila(2);
	p.Push(3);
	p.Push(5);
	p.Push(4)
	p.Push(4);
	p.Pop();
	
	return 0;
}
